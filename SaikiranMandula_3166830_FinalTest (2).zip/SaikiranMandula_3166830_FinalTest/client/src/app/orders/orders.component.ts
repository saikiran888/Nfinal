import { Component, OnInit } from '@angular/core';
import { IOrder } from '../shared/models/order';
import { OrdersService } from './orders.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss']
})
export class OrdersComponent implements OnInit {
  orders: IOrder[];

  constructor(private ordersService: OrdersService) {

   }

  ngOnInit(): void {
    this.getOrders();

  }




  final(){
    let  total=0;
    var array = this.orders;

    for (var i = 0; i < array.length; i++) {
        var element = array[i];
        console.log(element.total);
        // how to add each price and get a total
        total +=Number(element.total);

    }
    return Math.round((total)/100*5);



}
  getOrders() {
    this.ordersService.getOrderForUser().subscribe((orders: IOrder[]) => {
      this.orders = orders;
    }, error => {
      console.log(error);
    });
  }

}
