import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShopComponent } from './shop.component';
import { ProductItemComponent } from './product-item/product-item.component';
import { SharedModule } from '../shared/shared.module';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ShopRoutingModule } from './shop-routing.module';
import { RatingComponent } from './rating/rating.component';
import { DropdownComponent } from './dropdown/dropdown.component';

@NgModule({
  declarations: [ShopComponent, ProductItemComponent, ProductDetailsComponent, RatingComponent, DropdownComponent],
  imports: [
    CommonModule,
    SharedModule,
    ShopRoutingModule,

  ],
  // We need to export it from here, so that the app.module can make use of it
  // export is removed after lazy loading has been added
  exports: []
})
export class ShopModule { }
