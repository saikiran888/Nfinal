import { Component } from '@angular/core';



@Component({
selector: 'app-dropdown',
templateUrl: './dropdown.component.html',
styleUrls: ['./dropdown.component.scss']
})

export class DropdownComponent {
  minDate = new Date();
players = [

	"02:15 PM",
	"06:15 PM",
	"09:15 PM"

]
selected = "----"

update(e){
	this.selected = e.target.value
}
}
