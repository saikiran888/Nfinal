import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.scss']
})
export class RatingComponent implements OnInit {
  arr: any[] = [];
  index:number = -1;
  constructor() {
    this.arr = [1, 2, 3, 4, 5];
   }

   onClickItem(index) {
    //console.log(index);
    this.index = index;
  }
  ngOnInit(): void {
  }

}
